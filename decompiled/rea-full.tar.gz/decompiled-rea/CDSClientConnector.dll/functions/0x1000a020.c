// rea decompile_all
// name: FUN_1000a020
// address: 0x1000a020
// body: available
// range: 0x1000a020-0x1000a083 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void __thiscall FUN_1000a020(uint3 param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined1 uVar1;
  byte *pbVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iVar6;
  undefined4 uStack_8;
  
  uStack_8 = (uint)param_1;
  uVar1 = _Char_traits_cat<>(&param_4);
  uStack_8._0_3_ = CONCAT12(uVar1,(undefined2)uStack_8);
  pbVar2 = (byte *)FUN_10008b80((int)&uStack_8 + 1);
  uVar5 = (uint)*pbVar2;
  iVar6 = param_4;
  puVar3 = (undefined4 *)FUN_1000a110(&param_3);
  puVar4 = (undefined4 *)FUN_1000a110(&param_2);
  FUN_1000a310(puVar4,puVar3,iVar6,uVar5,uVar1);
  return;
}

