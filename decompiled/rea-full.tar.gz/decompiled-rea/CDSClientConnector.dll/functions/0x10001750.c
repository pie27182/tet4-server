// rea decompile_all
// name: FUN_10001750
// address: 0x10001750
// body: available
// range: 0x10001750-0x100017c4 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


int __cdecl
FUN_10001750(_THandle *param_1,
            basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2)

{
  bool bVar1;
  uint3 extraout_var;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint local_8;
  
  local_8 = 0;
  bVar1 = FUN_10005480(param_1,&local_8);
  uVar4 = CONCAT31(extraout_var,bVar1);
  if (bVar1) {
    if ((int)local_8 < 0x19001) {
      if (0 < (int)local_8) {
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::resize
                  (param_2,local_8);
        uVar4 = local_8;
        pcVar3 = FUN_10001e40(param_2,0);
        uVar4 = XStream::Read(param_1,pcVar3,uVar4);
        if (uVar4 != local_8) {
          return uVar4 & 0xffffff00;
        }
      }
      iVar2 = CONCAT31((int3)(uVar4 >> 8),1);
    }
    else {
      iVar2 = (uint)extraout_var << 8;
    }
  }
  else {
    iVar2 = (uint)extraout_var << 8;
  }
  return iVar2;
}

