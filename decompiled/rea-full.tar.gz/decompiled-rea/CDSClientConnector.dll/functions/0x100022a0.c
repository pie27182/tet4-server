// rea decompile_all
// name: FUN_100022a0
// address: 0x100022a0
// body: available
// range: 0x100022a0-0x10002a71 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


undefined4 * __thiscall FUN_100022a0(void *this,undefined4 *param_1,int param_2,undefined4 param_3)

{
  _Container_proxy *p_Var1;
  int iVar2;
  char *pcVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined1 *puVar7;
  undefined1 *puVar8;
  _Container_proxy *local_70;
  _Container_proxy *local_6c;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_64 [28];
  undefined1 local_48 [40];
  _Container_proxy *local_20;
  _Container_proxy *local_1c;
  _Container_proxy *local_18;
  _Container_proxy *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10016e08;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  iVar2 = FUN_10003c90((int)&param_2);
  pcVar3 = (char *)FUN_10003050(iVar2);
  if (*pcVar3 != '\0') {
    basic_string<>(local_64,"invalid map/set<T> iterator");
    local_8 = 0;
    FID_conflict_length_error(local_48,local_64);
    __CxxThrowException_8(local_48,&DAT_1001a968);
    local_8 = 0xffffffff;
    FUN_10001e00(local_64);
  }
  local_14 = (_Container_proxy *)FUN_10003c90((int)&param_2);
  FUN_10003c20(&param_2);
  local_1c = local_14;
  piVar4 = (int *)FUN_10003080(local_14);
  pcVar3 = (char *)FUN_10003050(*piVar4);
  if (*pcVar3 == '\0') {
    piVar4 = (int *)FUN_100030a0((int)local_1c);
    pcVar3 = (char *)FUN_10003050(*piVar4);
    if (*pcVar3 == '\0') {
      local_1c = (_Container_proxy *)FUN_10003c90((int)&param_2);
      piVar4 = (int *)FUN_100030a0((int)local_1c);
      local_18 = (_Container_proxy *)*piVar4;
    }
    else {
      piVar4 = (int *)FUN_10003080(local_1c);
      local_18 = (_Container_proxy *)*piVar4;
    }
  }
  else {
    piVar4 = (int *)FUN_100030a0((int)local_1c);
    local_18 = (_Container_proxy *)*piVar4;
  }
  if (local_1c == local_14) {
    piVar4 = (int *)FUN_10003090((int)local_14);
    local_20 = (_Container_proxy *)*piVar4;
    pcVar3 = (char *)FUN_10003050((int)local_18);
    if (*pcVar3 == '\0') {
      piVar4 = (int *)FUN_10003090((int)local_18);
      *piVar4 = (int)local_20;
    }
    piVar4 = (int *)FUN_100039c0((int)this);
    if ((_Container_proxy *)*piVar4 == local_14) {
      piVar4 = (int *)FUN_100039c0((int)this);
      *piVar4 = (int)local_18;
    }
    else {
      piVar4 = (int *)FUN_10003080(local_20);
      if ((_Container_proxy *)*piVar4 == local_14) {
        piVar4 = (int *)FUN_10003080(local_20);
        *piVar4 = (int)local_18;
      }
      else {
        piVar4 = (int *)FUN_100030a0((int)local_20);
        *piVar4 = (int)local_18;
      }
    }
    piVar4 = (int *)FUN_100037d0((int)this);
    if ((_Container_proxy *)*piVar4 == local_14) {
      pcVar3 = (char *)FUN_10003050((int)local_18);
      if (*pcVar3 == '\0') {
        local_6c = (_Container_proxy *)FUN_10003960(local_18);
      }
      else {
        local_6c = local_20;
      }
      piVar4 = (int *)FUN_100037d0((int)this);
      *piVar4 = (int)local_6c;
    }
    piVar4 = (int *)FUN_100039a0((int)this);
    if ((_Container_proxy *)*piVar4 == local_14) {
      pcVar3 = (char *)FUN_10003050((int)local_18);
      if (*pcVar3 == '\0') {
        local_70 = (_Container_proxy *)FUN_10003920((int)local_18);
      }
      else {
        local_70 = local_20;
      }
      piVar4 = (int *)FUN_100039a0((int)this);
      *piVar4 = (int)local_70;
    }
  }
  else {
    piVar4 = (int *)FUN_10003080(local_14);
    piVar4 = (int *)FUN_10003090(*piVar4);
    *piVar4 = (int)local_1c;
    puVar5 = (undefined4 *)FUN_10003080(local_14);
    puVar6 = (undefined4 *)FUN_10003080(local_1c);
    *puVar6 = *puVar5;
    piVar4 = (int *)FUN_100030a0((int)local_14);
    if (local_1c == (_Container_proxy *)*piVar4) {
      local_20 = local_1c;
    }
    else {
      piVar4 = (int *)FUN_10003090((int)local_1c);
      local_20 = (_Container_proxy *)*piVar4;
      pcVar3 = (char *)FUN_10003050((int)local_18);
      if (*pcVar3 == '\0') {
        piVar4 = (int *)FUN_10003090((int)local_18);
        *piVar4 = (int)local_20;
      }
      piVar4 = (int *)FUN_10003080(local_20);
      *piVar4 = (int)local_18;
      puVar5 = (undefined4 *)FUN_100030a0((int)local_14);
      puVar6 = (undefined4 *)FUN_100030a0((int)local_1c);
      *puVar6 = *puVar5;
      piVar4 = (int *)FUN_100030a0((int)local_14);
      piVar4 = (int *)FUN_10003090(*piVar4);
      *piVar4 = (int)local_1c;
    }
    piVar4 = (int *)FUN_100039c0((int)this);
    if ((_Container_proxy *)*piVar4 == local_14) {
      piVar4 = (int *)FUN_100039c0((int)this);
      *piVar4 = (int)local_1c;
    }
    else {
      puVar5 = (undefined4 *)FUN_10003090((int)local_14);
      piVar4 = (int *)FUN_10003080(*puVar5);
      if ((_Container_proxy *)*piVar4 == local_14) {
        puVar5 = (undefined4 *)FUN_10003090((int)local_14);
        piVar4 = (int *)FUN_10003080(*puVar5);
        *piVar4 = (int)local_1c;
      }
      else {
        piVar4 = (int *)FUN_10003090((int)local_14);
        piVar4 = (int *)FUN_100030a0(*piVar4);
        *piVar4 = (int)local_1c;
      }
    }
    puVar5 = (undefined4 *)FUN_10003090((int)local_14);
    puVar6 = (undefined4 *)FUN_10003090((int)local_1c);
    *puVar6 = *puVar5;
    puVar7 = (undefined1 *)FUN_10003040((int)local_14);
    puVar8 = (undefined1 *)FUN_10003040((int)local_1c);
    FUN_10005740(puVar8,puVar7);
  }
  pcVar3 = (char *)FUN_10003040((int)local_14);
  if (*pcVar3 != '\x01') {
LAB_10002a11:
    std::allocator<std::_Container_proxy>::destroy
              ((allocator<std::_Container_proxy> *)((int)this + 0xc),local_14);
    FUN_10007b50(local_14);
    if (*(int *)((int)this + 0x1c) != 0) {
      *(int *)((int)this + 0x1c) = *(int *)((int)this + 0x1c) + -1;
    }
    FUN_10003150(this,param_1,param_2,param_3);
    ExceptionList = local_10;
    return param_1;
  }
LAB_10002695:
  piVar4 = (int *)FUN_100039c0((int)this);
  if ((local_18 == (_Container_proxy *)*piVar4) ||
     (pcVar3 = (char *)FUN_10003040((int)local_18), *pcVar3 != '\x01')) goto LAB_10002a02;
  piVar4 = (int *)FUN_10003080(local_20);
  if (local_18 == (_Container_proxy *)*piVar4) {
    piVar4 = (int *)FUN_100030a0((int)local_20);
    local_1c = (_Container_proxy *)*piVar4;
    pcVar3 = (char *)FUN_10003040((int)local_1c);
    if (*pcVar3 == '\0') {
      puVar7 = (undefined1 *)FUN_10003040((int)local_1c);
      *puVar7 = 1;
      puVar7 = (undefined1 *)FUN_10003040((int)local_20);
      *puVar7 = 0;
      FUN_100037f0(this,(int)local_20);
      piVar4 = (int *)FUN_100030a0((int)local_20);
      local_1c = (_Container_proxy *)*piVar4;
    }
    pcVar3 = (char *)FUN_10003050((int)local_1c);
    p_Var1 = local_20;
    if (*pcVar3 == '\0') {
      piVar4 = (int *)FUN_10003080(local_1c);
      pcVar3 = (char *)FUN_10003040(*piVar4);
      if (*pcVar3 == '\x01') {
        piVar4 = (int *)FUN_100030a0((int)local_1c);
        pcVar3 = (char *)FUN_10003040(*piVar4);
        if (*pcVar3 == '\x01') {
          puVar7 = (undefined1 *)FUN_10003040((int)local_1c);
          *puVar7 = 0;
          p_Var1 = local_20;
          goto LAB_10002684;
        }
      }
      piVar4 = (int *)FUN_100030a0((int)local_1c);
      pcVar3 = (char *)FUN_10003040(*piVar4);
      if (*pcVar3 == '\x01') {
        piVar4 = (int *)FUN_10003080(local_1c);
        puVar7 = (undefined1 *)FUN_10003040(*piVar4);
        *puVar7 = 1;
        puVar7 = (undefined1 *)FUN_10003040((int)local_1c);
        *puVar7 = 0;
        FUN_100039e0(this,(int)local_1c);
        piVar4 = (int *)FUN_100030a0((int)local_20);
        local_1c = (_Container_proxy *)*piVar4;
      }
      puVar7 = (undefined1 *)FUN_10003040((int)local_20);
      puVar8 = (undefined1 *)FUN_10003040((int)local_1c);
      *puVar8 = *puVar7;
      puVar7 = (undefined1 *)FUN_10003040((int)local_20);
      *puVar7 = 1;
      piVar4 = (int *)FUN_100030a0((int)local_1c);
      puVar7 = (undefined1 *)FUN_10003040(*piVar4);
      *puVar7 = 1;
      FUN_100037f0(this,(int)local_20);
LAB_10002a02:
      puVar7 = (undefined1 *)FUN_10003040((int)local_18);
      *puVar7 = 1;
      goto LAB_10002a11;
    }
  }
  else {
    piVar4 = (int *)FUN_10003080(local_20);
    local_1c = (_Container_proxy *)*piVar4;
    pcVar3 = (char *)FUN_10003040((int)local_1c);
    if (*pcVar3 == '\0') {
      puVar7 = (undefined1 *)FUN_10003040((int)local_1c);
      *puVar7 = 1;
      puVar7 = (undefined1 *)FUN_10003040((int)local_20);
      *puVar7 = 0;
      FUN_100039e0(this,(int)local_20);
      piVar4 = (int *)FUN_10003080(local_20);
      local_1c = (_Container_proxy *)*piVar4;
    }
    pcVar3 = (char *)FUN_10003050((int)local_1c);
    if (*pcVar3 == '\0') {
      piVar4 = (int *)FUN_100030a0((int)local_1c);
      pcVar3 = (char *)FUN_10003040(*piVar4);
      if (*pcVar3 == '\x01') {
        piVar4 = (int *)FUN_10003080(local_1c);
        pcVar3 = (char *)FUN_10003040(*piVar4);
        if (*pcVar3 == '\x01') {
          puVar7 = (undefined1 *)FUN_10003040((int)local_1c);
          *puVar7 = 0;
          local_18 = local_20;
          p_Var1 = local_18;
          goto LAB_10002684;
        }
      }
      piVar4 = (int *)FUN_10003080(local_1c);
      pcVar3 = (char *)FUN_10003040(*piVar4);
      if (*pcVar3 == '\x01') {
        piVar4 = (int *)FUN_100030a0((int)local_1c);
        puVar7 = (undefined1 *)FUN_10003040(*piVar4);
        *puVar7 = 1;
        puVar7 = (undefined1 *)FUN_10003040((int)local_1c);
        *puVar7 = 0;
        FUN_100037f0(this,(int)local_1c);
        piVar4 = (int *)FUN_10003080(local_20);
        local_1c = (_Container_proxy *)*piVar4;
      }
      puVar7 = (undefined1 *)FUN_10003040((int)local_20);
      puVar8 = (undefined1 *)FUN_10003040((int)local_1c);
      *puVar8 = *puVar7;
      puVar7 = (undefined1 *)FUN_10003040((int)local_20);
      *puVar7 = 1;
      piVar4 = (int *)FUN_10003080(local_1c);
      puVar7 = (undefined1 *)FUN_10003040(*piVar4);
      *puVar7 = 1;
      FUN_100039e0(this,(int)local_20);
      goto LAB_10002a02;
    }
    local_18 = local_20;
    p_Var1 = local_18;
  }
LAB_10002684:
  local_18 = p_Var1;
  local_20 = local_18;
  piVar4 = (int *)FUN_10003090((int)local_18);
  local_20 = (_Container_proxy *)*piVar4;
  goto LAB_10002695;
}

