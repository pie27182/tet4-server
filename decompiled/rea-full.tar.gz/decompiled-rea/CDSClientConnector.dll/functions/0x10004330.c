// rea decompile_all
// name: FUN_10004330
// address: 0x10004330
// body: available
// range: 0x10004330-0x100047a3 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void * __thiscall
FUN_10004330(void *this,void *param_1,char param_2,int param_3,undefined4 *param_4)

{
  int iVar1;
  int *piVar2;
  char *pcVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined1 *puVar6;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_5c [28];
  undefined1 local_40 [40];
  int local_18;
  int local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10016dd8;
  local_10 = ExceptionList;
  ExceptionList = &local_10;
  iVar1 = FUN_10004d30();
  if (iVar1 - 1U <= *(uint *)((int)this + 0x1c)) {
    basic_string<>(local_5c,"map/set<T> too long");
    local_8 = 0;
    FID_conflict_length_error(local_40,local_5c);
    __CxxThrowException_8(local_40,&DAT_1001a9a4);
    local_8 = 0xffffffff;
    FUN_10001e00(local_5c);
  }
  local_14 = FUN_10004f20(*(undefined4 *)((int)this + 0x18),param_3,
                          *(undefined4 *)((int)this + 0x18),param_4,0);
  *(int *)((int)this + 0x1c) = *(int *)((int)this + 0x1c) + 1;
  if (param_3 == *(int *)((int)this + 0x18)) {
    piVar2 = (int *)FUN_100039c0((int)this);
    *piVar2 = local_14;
    piVar2 = (int *)FUN_100037d0((int)this);
    *piVar2 = local_14;
    piVar2 = (int *)FUN_100039a0((int)this);
    *piVar2 = local_14;
  }
  else if (param_2 == '\0') {
    piVar2 = (int *)FUN_100030a0(param_3);
    *piVar2 = local_14;
    piVar2 = (int *)FUN_100039a0((int)this);
    if (param_3 == *piVar2) {
      piVar2 = (int *)FUN_100039a0((int)this);
      *piVar2 = local_14;
    }
  }
  else {
    piVar2 = (int *)FUN_10003080(param_3);
    *piVar2 = local_14;
    piVar2 = (int *)FUN_100037d0((int)this);
    if (param_3 == *piVar2) {
      piVar2 = (int *)FUN_100037d0((int)this);
      *piVar2 = local_14;
    }
  }
  local_18 = local_14;
  while( true ) {
    piVar2 = (int *)FUN_10003090(local_18);
    pcVar3 = (char *)FUN_10003040(*piVar2);
    if (*pcVar3 != '\0') break;
    piVar2 = (int *)FUN_10003090(local_18);
    piVar4 = (int *)FUN_10003090(local_18);
    puVar5 = (undefined4 *)FUN_10003090(*piVar4);
    piVar4 = (int *)FUN_10003080(*puVar5);
    if (*piVar2 == *piVar4) {
      piVar2 = (int *)FUN_10003090(local_18);
      piVar2 = (int *)FUN_10003090(*piVar2);
      piVar2 = (int *)FUN_100030a0(*piVar2);
      iVar1 = *piVar2;
      pcVar3 = (char *)FUN_10003040(iVar1);
      if (*pcVar3 == '\0') {
        piVar2 = (int *)FUN_10003090(local_18);
        puVar6 = (undefined1 *)FUN_10003040(*piVar2);
        *puVar6 = 1;
        puVar6 = (undefined1 *)FUN_10003040(iVar1);
        *puVar6 = 1;
        piVar2 = (int *)FUN_10003090(local_18);
        piVar2 = (int *)FUN_10003090(*piVar2);
        puVar6 = (undefined1 *)FUN_10003040(*piVar2);
        *puVar6 = 0;
        piVar2 = (int *)FUN_10003090(local_18);
        piVar2 = (int *)FUN_10003090(*piVar2);
        local_18 = *piVar2;
      }
      else {
        piVar2 = (int *)FUN_10003090(local_18);
        piVar2 = (int *)FUN_100030a0(*piVar2);
        if (local_18 == *piVar2) {
          piVar2 = (int *)FUN_10003090(local_18);
          local_18 = *piVar2;
          FUN_100037f0(this,local_18);
        }
        piVar2 = (int *)FUN_10003090(local_18);
        puVar6 = (undefined1 *)FUN_10003040(*piVar2);
        *puVar6 = 1;
        piVar2 = (int *)FUN_10003090(local_18);
        piVar2 = (int *)FUN_10003090(*piVar2);
        puVar6 = (undefined1 *)FUN_10003040(*piVar2);
        *puVar6 = 0;
        piVar2 = (int *)FUN_10003090(local_18);
        piVar2 = (int *)FUN_10003090(*piVar2);
        FUN_100039e0(this,*piVar2);
      }
    }
    else {
      piVar2 = (int *)FUN_10003090(local_18);
      puVar5 = (undefined4 *)FUN_10003090(*piVar2);
      piVar2 = (int *)FUN_10003080(*puVar5);
      iVar1 = *piVar2;
      pcVar3 = (char *)FUN_10003040(iVar1);
      if (*pcVar3 == '\0') {
        piVar2 = (int *)FUN_10003090(local_18);
        puVar6 = (undefined1 *)FUN_10003040(*piVar2);
        *puVar6 = 1;
        puVar6 = (undefined1 *)FUN_10003040(iVar1);
        *puVar6 = 1;
        piVar2 = (int *)FUN_10003090(local_18);
        piVar2 = (int *)FUN_10003090(*piVar2);
        puVar6 = (undefined1 *)FUN_10003040(*piVar2);
        *puVar6 = 0;
        piVar2 = (int *)FUN_10003090(local_18);
        piVar2 = (int *)FUN_10003090(*piVar2);
        local_18 = *piVar2;
      }
      else {
        puVar5 = (undefined4 *)FUN_10003090(local_18);
        piVar2 = (int *)FUN_10003080(*puVar5);
        if (local_18 == *piVar2) {
          piVar2 = (int *)FUN_10003090(local_18);
          local_18 = *piVar2;
          FUN_100039e0(this,local_18);
        }
        piVar2 = (int *)FUN_10003090(local_18);
        puVar6 = (undefined1 *)FUN_10003040(*piVar2);
        *puVar6 = 1;
        piVar2 = (int *)FUN_10003090(local_18);
        piVar2 = (int *)FUN_10003090(*piVar2);
        puVar6 = (undefined1 *)FUN_10003040(*piVar2);
        *puVar6 = 0;
        piVar2 = (int *)FUN_10003090(local_18);
        piVar2 = (int *)FUN_10003090(*piVar2);
        FUN_100037f0(this,*piVar2);
      }
    }
  }
  piVar2 = (int *)FUN_100039c0((int)this);
  puVar6 = (undefined1 *)FUN_10003040(*piVar2);
  *puVar6 = 1;
  _Vector_iterator<>(param_1,local_14,this);
  ExceptionList = local_10;
  return param_1;
}

