// rea decompile_all
// name: FUN_10009580
// address: 0x10009580
// body: available
// range: 0x10009580-0x100096e2 inclusive
// range: 0x100097d9-0x10009852 inclusive
// range: 0x100098d4-0x10009959 inclusive
// non_contiguous: true
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x100096e1 to 0x10009752 FUN_10009752 (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x10009851 to 0x10009888 FUN_10009888 (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void __thiscall FUN_10009580(void *this,undefined4 param_1,int param_2,uint param_3,void *param_4)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uStack_70;
  uint local_60;
  undefined4 local_58 [6];
  int local_40;
  undefined1 local_3c [24];
  int local_24;
  void *local_20;
  int local_1c;
  uint local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10017130;
  local_10 = ExceptionList;
  uStack_70 = DAT_1001d02c ^ (uint)(local_3c + 0x38);
  local_14 = (undefined1 *)&uStack_70;
  ExceptionList = &local_10;
  local_18 = FUN_10009100((int)this);
  if (param_3 != 0) {
    iVar1 = FUN_10008e50((int)this);
    iVar2 = FUN_10009530();
    if ((uint)(iVar2 - iVar1) < param_3) {
      FUN_10009970();
    }
    else {
      iVar1 = FUN_10008e50((int)this);
      if (local_18 < iVar1 + param_3) {
        uVar4 = local_18 >> 1;
        iVar1 = FUN_10009530();
        if (iVar1 - uVar4 < local_18) {
          local_60 = 0;
        }
        else {
          local_60 = (local_18 >> 1) + local_18;
        }
        local_18 = local_60;
        iVar1 = FUN_10008e50((int)this);
        if (local_18 < iVar1 + param_3) {
          iVar1 = FUN_10008e50((int)this);
          local_18 = iVar1 + param_3;
        }
        local_20 = (void *)FUN_100099f0(local_18);
        local_1c = (param_2 - *(int *)((int)this + 0xc)) / 0x18;
        local_24 = 0;
        local_8 = 0;
        FUN_10009360(this,(int)(local_1c * 0x18 + (int)local_20),param_3,param_4);
        local_24 = local_24 + 1;
        do_is(this,*(undefined4 *)((int)this + 0xc),param_2,local_20);
        local_24 = local_24 + 1;
        do_is(this,param_2,*(undefined4 *)((int)this + 0x10),
              (void *)((local_1c + param_3) * 0x18 + (int)local_20));
        FUN_10009752();
        return;
      }
      if ((uint)((*(int *)((int)this + 0x10) - param_2) / 0x18) < param_3) {
        FUN_10009c40(local_3c,param_4);
        local_8 = 2;
        do_is(this,param_2,*(undefined4 *)((int)this + 0x10),(void *)(param_3 * 0x18 + param_2));
        local_8 = CONCAT31(local_8._1_3_,3);
        FUN_10009360(this,*(int *)((int)this + 0x10),
                     param_3 - (*(int *)((int)this + 0x10) - param_2) / 0x18,local_3c);
        FUN_10009888();
        return;
      }
      FUN_10009c40(local_58,param_4);
      local_8 = 5;
      local_40 = *(int *)((int)this + 0x10);
      uVar3 = do_is(this,local_40 + param_3 * -0x18,local_40,*(void **)((int)this + 0x10));
      *(undefined4 *)((int)this + 0x10) = uVar3;
      iVar1 = local_40 + param_3 * -0x18;
      FUN_1000a020((uint3)iVar1,param_2,iVar1,local_40);
      FUN_10009ff0(param_2,param_3 * 0x18 + param_2,local_58);
      local_8 = 0xffffffff;
      ~function<>(local_58);
    }
  }
  ExceptionList = local_10;
  return;
}

