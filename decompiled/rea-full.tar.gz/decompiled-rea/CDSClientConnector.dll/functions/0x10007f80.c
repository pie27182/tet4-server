// rea decompile_all
// name: FUN_10007f80
// address: 0x10007f80
// body: available
// range: 0x10007f80-0x10008023 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x10008022 to 0x1000804d FUN_1000804d (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void __thiscall FUN_10007f80(void *this,uint param_1)

{
  uint uVar1;
  void *pvVar2;
  undefined4 *puVar3;
  undefined1 uVar4;
  undefined4 uVar5;
  uint uStack_40;
  undefined1 local_2c [8];
  undefined1 local_24 [12];
  void *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10016f00;
  local_10 = ExceptionList;
  uStack_40 = DAT_1001d02c ^ (uint)(local_24 + 0x20);
  local_14 = (undefined1 *)&uStack_40;
  ExceptionList = &local_10;
  uVar1 = FUN_10007a80();
  if (uVar1 < param_1) {
    FUN_10009970();
  }
  else {
    uVar1 = FUN_10008290((int)this);
    if (uVar1 < param_1) {
      pvVar2 = (void *)FUN_10007b70(param_1);
      local_8 = 0;
      local_18 = pvVar2;
      puVar3 = FUN_10008e20(this,local_24);
      uVar5 = puVar3[1];
      uVar4 = (undefined1)*puVar3;
      puVar3 = FUN_100075e0(this,local_2c);
      FUN_100087d0(this,(char)*puVar3,puVar3[1],uVar4,uVar5,pvVar2);
      FUN_1000804d();
      return;
    }
  }
  ExceptionList = local_10;
  return;
}

