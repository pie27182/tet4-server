// rea decompile_all
// name: FUN_10006245
// address: 0x10006245
// body: available
// range: 0x10006245-0x100062cb inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void FUN_10006245(void)

{
  int iVar1;
  uint unaff_EBP;
  undefined4 uStack0000000c;
  
  *(undefined4 *)(unaff_EBP - 4) = 0xffffffff;
  iVar1 = FUN_10002e10(*(int *)(unaff_EBP - 100));
  *(int *)(unaff_EBP + 0x10) = iVar1 + *(int *)(unaff_EBP + 0x10);
  if (*(int *)(*(int *)(unaff_EBP - 100) + 0xc) != 0) {
    FUN_10002f50(*(void **)(unaff_EBP - 100),*(void **)(*(int *)(unaff_EBP - 100) + 0xc),
                 *(void **)(*(int *)(unaff_EBP - 100) + 0x10));
    FUN_10007b50(*(void **)(*(int *)(unaff_EBP - 100) + 0xc));
  }
  *(int *)(*(int *)(unaff_EBP - 100) + 0x14) =
       *(int *)(unaff_EBP - 0x14) * 0x1c + *(int *)(unaff_EBP - 0x1c);
  *(int *)(*(int *)(unaff_EBP - 100) + 0x10) =
       *(int *)(unaff_EBP + 0x10) * 0x1c + *(int *)(unaff_EBP - 0x1c);
  *(undefined4 *)(*(int *)(unaff_EBP - 100) + 0xc) = *(undefined4 *)(unaff_EBP - 0x1c);
  ExceptionList = *(void **)(unaff_EBP - 0xc);
  uStack0000000c = 0x10006465;
  __security_check_cookie(*(uint *)(unaff_EBP - 0x24) ^ unaff_EBP);
  return;
}

