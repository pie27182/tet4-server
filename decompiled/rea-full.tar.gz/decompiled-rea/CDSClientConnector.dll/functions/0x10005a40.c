// rea decompile_all
// name: FUN_10005a40
// address: 0x10005a40
// body: available
// range: 0x10005a40-0x10005b3c inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void __cdecl FUN_10005a40(_THandle *param_1,void *param_2)

{
  bool bVar1;
  allocator<char> local_38 [28];
  uint local_1c;
  int local_18;
  uint local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10016fe8;
  local_10 = ExceptionList;
  local_1c = DAT_1001d02c ^ (uint)(local_38 + 0x34);
  ExceptionList = &local_10;
  local_14 = 0;
  bVar1 = FUN_10005480(param_1,&local_14);
  if ((bVar1) && ((int)local_14 < 0x19001)) {
    FUN_10005c70(param_2,local_14);
    for (local_18 = 0; local_18 < (int)local_14; local_18 = local_18 + 1) {
      FUN_100016d0(local_38);
      local_8 = 0;
      bVar1 = FUN_10005f80(param_1,(basic_string<char,std::char_traits<char>,std::allocator<char>_>
                                    *)local_38);
      if (!bVar1) {
        local_8 = 0xffffffff;
        FUN_10001e00(local_38);
        break;
      }
      FUN_10005e00(param_2,local_38);
      local_8 = 0xffffffff;
      FUN_10001e00(local_38);
    }
  }
  ExceptionList = local_10;
  __security_check_cookie(local_1c ^ (uint)(local_38 + 0x34));
  return;
}

