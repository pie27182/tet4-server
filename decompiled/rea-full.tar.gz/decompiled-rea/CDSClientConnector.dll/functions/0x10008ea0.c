// rea decompile_all
// name: FUN_10008ea0
// address: 0x10008ea0
// body: available
// range: 0x10008ea0-0x10008f12 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void __thiscall FUN_10008ea0(void *this,void *param_1)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 local_1c [2];
  undefined1 local_14 [8];
  undefined4 local_c;
  int local_8;
  
  uVar1 = FUN_10008e50((int)this);
  uVar2 = FUN_10009100((int)this);
  if (uVar1 < uVar2) {
    iVar3 = FUN_10009360(this,*(int *)((int)this + 0x10),1,param_1);
    *(int *)((int)this + 0x10) = iVar3;
  }
  else {
    puVar4 = FUN_10008e20(this,local_14);
    local_c = *puVar4;
    local_8 = puVar4[1];
    FUN_10009140(this,local_1c,local_c,local_8,param_1);
  }
  return;
}

