// rea decompile_all
// name: FUN_10007820
// address: 0x10007820
// body: available
// range: 0x10007820-0x1000784e inclusive
// range: 0x10007851-0x1000789f inclusive
// non_contiguous: true
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


uint __thiscall FUN_10007820(void *this,uint param_1)

{
  uint uVar1;
  undefined4 uVar2;
  
  *(undefined4 *)((int)this + 0xc) = 0;
  *(undefined4 *)((int)this + 0x10) = 0;
  *(undefined4 *)((int)this + 0x14) = 0;
  if (param_1 == 0) {
    uVar1 = (uint)this & 0xffffff00;
  }
  else {
    uVar1 = FUN_10007a80();
    if (uVar1 < param_1) {
      this = (void *)FUN_10009970();
    }
    else {
      uVar2 = FUN_10007b70(param_1);
      *(undefined4 *)((int)this + 0xc) = uVar2;
      *(undefined4 *)((int)this + 0x10) = *(undefined4 *)((int)this + 0xc);
      *(uint *)((int)this + 0x14) = *(int *)((int)this + 0xc) + param_1 * 4;
    }
    uVar1 = CONCAT31((int3)((uint)this >> 8),1);
  }
  return uVar1;
}

