// rea decompile_all
// name: FUN_10001f60
// address: 0x10001f60
// body: available
// range: 0x10001f60-0x100020e7 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void * __thiscall FUN_10001f60(void *this,void *param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  void *pvVar4;
  undefined4 uVar5;
  
  if (this != param_1) {
    iVar1 = FUN_10002e10((int)param_1);
    if (iVar1 == 0) {
      FUN_100020f0(this);
    }
    else {
      uVar2 = FUN_10002e10((int)param_1);
      uVar3 = FUN_10002e10((int)this);
      if (uVar3 < uVar2) {
        uVar2 = FUN_10002e10((int)param_1);
        uVar3 = FUN_10002dd0((int)this);
        if (uVar3 < uVar2) {
          if (*(int *)((int)this + 0xc) != 0) {
            FUN_10002f50(this,*(void **)((int)this + 0xc),*(void **)((int)this + 0x10));
            FUN_10007b50(*(void **)((int)this + 0xc));
          }
          uVar2 = FUN_10002e10((int)param_1);
          uVar2 = FUN_10002ed0(this,uVar2);
          if ((uVar2 & 0xff) != 0) {
            uVar5 = do_is(this,*(undefined4 *)((int)param_1 + 0xc),
                          *(undefined4 *)((int)param_1 + 0x10),*(int *)((int)this + 0xc));
            *(undefined4 *)((int)this + 0x10) = uVar5;
          }
        }
        else {
          iVar1 = FUN_10002e10((int)this);
          iVar1 = iVar1 * 0x1c + *(int *)((int)param_1 + 0xc);
          FUN_100056a0((uint3)iVar1,*(undefined4 *)((int)param_1 + 0xc),iVar1,
                       *(int *)((int)this + 0xc));
          uVar5 = do_is(this,iVar1,*(undefined4 *)((int)param_1 + 0x10),*(int *)((int)this + 0x10));
          *(undefined4 *)((int)this + 0x10) = uVar5;
        }
      }
      else {
        pvVar4 = (void *)FUN_100056a0((uint3)*(undefined4 *)((int)param_1 + 0x10),
                                      *(undefined4 *)((int)param_1 + 0xc),
                                      *(undefined4 *)((int)param_1 + 0x10),*(int *)((int)this + 0xc)
                                     );
        FUN_10002f50(this,pvVar4,*(void **)((int)this + 0x10));
        iVar1 = FUN_10002e10((int)param_1);
        *(int *)((int)this + 0x10) = iVar1 * 0x1c + *(int *)((int)this + 0xc);
      }
    }
  }
  return this;
}

