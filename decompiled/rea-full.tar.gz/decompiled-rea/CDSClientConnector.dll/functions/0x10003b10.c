// rea decompile_all
// name: FUN_10003b10
// address: 0x10003b10
// body: available
// range: 0x10003b10-0x10003bdf inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void __fastcall FUN_10003b10(void *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  _Container_proxy *p_Var3;
  undefined4 local_2c [2];
  undefined1 local_24 [8];
  undefined4 local_1c;
  undefined4 local_18;
  undefined1 local_14 [8];
  int local_c;
  int local_8;
  
  piVar1 = FUN_10003120(param_1,local_14);
  local_c = *piVar1;
  local_8 = piVar1[1];
  puVar2 = FUN_10003ff0(param_1,local_24);
  local_1c = *puVar2;
  local_18 = puVar2[1];
  FUN_10004210(param_1,local_2c,local_1c,local_18,local_c);
  p_Var3 = (_Container_proxy *)FUN_10003080(*(undefined4 *)((int)param_1 + 0x18));
  std::allocator<std::_Container_proxy>::destroy
            ((allocator<std::_Container_proxy> *)((int)param_1 + 0x10),p_Var3);
  p_Var3 = (_Container_proxy *)FUN_10003090(*(int *)((int)param_1 + 0x18));
  std::allocator<std::_Container_proxy>::destroy
            ((allocator<std::_Container_proxy> *)((int)param_1 + 0x10),p_Var3);
  p_Var3 = (_Container_proxy *)FUN_100030a0(*(int *)((int)param_1 + 0x18));
  std::allocator<std::_Container_proxy>::destroy
            ((allocator<std::_Container_proxy> *)((int)param_1 + 0x10),p_Var3);
  FUN_10007b50(*(void **)((int)param_1 + 0x18));
  *(undefined4 *)((int)param_1 + 0x18) = 0;
  *(undefined4 *)((int)param_1 + 0x1c) = 0;
  return;
}

