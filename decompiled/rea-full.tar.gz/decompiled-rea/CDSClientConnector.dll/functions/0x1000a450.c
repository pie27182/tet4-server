// rea decompile_all
// name: FUN_1000a450
// address: 0x1000a450
// body: available
// range: 0x1000a450-0x1000a4d4 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1000a4d3 to 0x1000a50c FUN_1000a50c (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void FUN_1000a450(undefined4 *param_1,undefined4 *param_2,void *param_3)

{
  uint uStack_44;
  undefined4 local_30 [6];
  void *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_100170f8;
  local_10 = ExceptionList;
  uStack_44 = DAT_1001d02c ^ (uint)(local_30 + 0xb);
  local_14 = (undefined1 *)&uStack_44;
  ExceptionList = &local_10;
  local_18 = param_3;
  FUN_10001ed0(local_30);
  local_8 = 1;
  for (; param_1 != param_2; param_1 = param_1 + 6) {
    FUN_1000a3d0(param_3,local_30);
    iter_swap<>(param_3,param_1);
    param_3 = (void *)((int)param_3 + 0x18);
  }
  FUN_1000a50c();
  return;
}

