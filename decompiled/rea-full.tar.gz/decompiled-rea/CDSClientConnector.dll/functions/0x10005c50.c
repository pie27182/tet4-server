// rea decompile_all
// name: FID_conflict:copy_s<std::char_traits<wchar_t>_>
// address: 0x10005c50
// body: available
// range: 0x10005c50-0x10005c6c inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* Library Function - Multiple Matches With Different Base Names
    unsigned short * __cdecl std::_Traits_helper::copy_s<struct std::char_traits<unsigned short>
   >(unsigned short *,unsigned int,unsigned short const *,unsigned int,struct
   std::_Secure_char_traits_tag)
    wchar_t * __cdecl std::_Traits_helper::copy_s<struct std::char_traits<wchar_t> >(wchar_t
   *,unsigned int,wchar_t const *,unsigned int,struct std::_Secure_char_traits_tag)
    char * __cdecl std::_Traits_helper::move_s<struct std::char_traits<char> >(char *,unsigned
   int,char const *,unsigned int,struct std::_Secure_char_traits_tag)
    unsigned short * __cdecl std::_Traits_helper::move_s<struct std::char_traits<unsigned short>
   >(unsigned short *,unsigned int,unsigned short const *,unsigned int,struct
   std::_Secure_char_traits_tag)
     5 names - too many to list
   
   Library: Visual Studio 2008 Debug */

char * __cdecl
FID_conflict_copy_s<std::char_traits<wchar_t>_>
          (ushort *param_1,uint param_2,ushort *param_3,uint param_4)

{
  ushort *puVar1;
  
  puVar1 = FID_conflict__Move_s(param_1,param_2,param_3,param_4);
  return (char *)puVar1;
}

