// rea decompile_all
// name: FUN_10004210
// address: 0x10004210
// body: available
// range: 0x10004210-0x10004269 inclusive
// range: 0x1000426c-0x100042be inclusive
// non_contiguous: true
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Variable defined which should be unmapped: param_2 */

undefined4 * __thiscall
FUN_10004210(void *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  bool bVar1;
  int *piVar2;
  undefined4 local_24 [2];
  int local_1c [2];
  undefined1 local_14 [8];
  undefined1 local_c [8];
  
  piVar2 = FUN_10003ff0(param_1,local_c);
  bVar1 = FUN_10003c40(&param_3,piVar2);
  if (bVar1) {
    piVar2 = FUN_10003120(param_1,local_14);
    bVar1 = FUN_10003c40(&param_5,piVar2);
    if (bVar1) {
      FUN_10004d50(param_1);
      FUN_10003ff0(param_1,param_2);
      return param_2;
    }
  }
  while (bVar1 = FUN_100050e0(&param_3,&param_5), bVar1) {
    piVar2 = FUN_100050a0(&param_3,local_1c);
    FUN_100022a0(param_1,local_24,*piVar2,piVar2[1]);
  }
  FUN_10003150(param_1,param_2,param_3,param_4);
  return param_2;
}

