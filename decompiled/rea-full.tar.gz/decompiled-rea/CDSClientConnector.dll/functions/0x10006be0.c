// rea decompile_all
// name: FUN_10006be0
// address: 0x10006be0
// body: available
// range: 0x10006be0-0x10006d21 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void __thiscall
FUN_10006be0(void *this,
            basic_string<char,struct_std::char_traits<char>,class_std::_DebugHeapAllocator<char>_>
            *param_1)

{
  char cVar1;
  basic_string<char,struct_std::char_traits<char>,class_std::_DebugHeapAllocator<char>_>
  local_48 [28];
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  uint local_18;
  undefined4 local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10016d58;
  local_10 = ExceptionList;
  local_18 = DAT_1001d02c ^ (uint)(local_48 + 0x44);
  ExceptionList = &local_10;
  if (this != param_1) {
    cVar1 = FUN_1000a850();
    if (cVar1 == '\0') {
      FUN_10001dc0(local_48,this);
      local_8 = 0;
      FUN_10006770(this,param_1);
      FUN_10006770(param_1,local_48);
      local_8 = 0xffffffff;
      FUN_10001e00(local_48);
    }
    else {
      local_28 = *(undefined4 *)((int)this + 4);
      local_24 = *(undefined4 *)((int)this + 8);
      local_20 = *(undefined4 *)((int)this + 0xc);
      local_1c = *(undefined4 *)((int)this + 0x10);
      *(undefined4 *)((int)this + 4) = *(undefined4 *)(param_1 + 4);
      *(undefined4 *)((int)this + 8) = *(undefined4 *)(param_1 + 8);
      *(undefined4 *)((int)this + 0xc) = *(undefined4 *)(param_1 + 0xc);
      *(undefined4 *)((int)this + 0x10) = *(undefined4 *)(param_1 + 0x10);
      *(undefined4 *)(param_1 + 4) = local_28;
      *(undefined4 *)(param_1 + 8) = local_24;
      *(undefined4 *)(param_1 + 0xc) = local_20;
      *(undefined4 *)(param_1 + 0x10) = local_1c;
      local_14 = *(undefined4 *)((int)this + 0x14);
      *(undefined4 *)((int)this + 0x14) = *(undefined4 *)(param_1 + 0x14);
      *(undefined4 *)(param_1 + 0x14) = local_14;
      local_2c = *(undefined4 *)((int)this + 0x18);
      *(undefined4 *)((int)this + 0x18) = *(undefined4 *)(param_1 + 0x18);
      *(undefined4 *)(param_1 + 0x18) = local_2c;
    }
  }
  ExceptionList = local_10;
  __security_check_cookie(local_18 ^ (uint)(local_48 + 0x44));
  return;
}

