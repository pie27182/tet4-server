// rea decompile_all
// name: FUN_10008390
// address: 0x10008390
// body: available
// range: 0x10008390-0x100084eb inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x100084ea to 0x10008559 FUN_10008559 (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


void __thiscall
FUN_10008390(void *this,undefined4 param_1,int param_2,uint param_3,undefined4 *param_4)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  uint uStack_48;
  uint local_38;
  undefined4 uStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  int local_24;
  void *local_20;
  int local_1c;
  uint local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10016ee0;
  local_10 = ExceptionList;
  uStack_48 = DAT_1001d02c ^ (int)register0x00000010 - 4U;
  local_14 = (undefined1 *)&uStack_48;
  ExceptionList = &local_10;
  local_18 = FUN_10008290((int)this);
  if (param_3 != 0) {
    iVar1 = FUN_10007a80();
    iVar2 = FUN_10007800((int)this);
    if ((uint)(iVar1 - iVar2) < param_3) {
      FUN_10009970();
    }
    else {
      iVar1 = FUN_10007800((int)this);
      if (local_18 < iVar1 + param_3) {
        iVar1 = FUN_10007a80();
        if (iVar1 - (local_18 >> 1) < local_18) {
          local_38 = 0;
        }
        else {
          local_38 = (local_18 >> 1) + local_18;
        }
        local_18 = local_38;
        iVar1 = FUN_10007800((int)this);
        if (local_18 < iVar1 + param_3) {
          iVar1 = FUN_10007800((int)this);
          local_18 = iVar1 + param_3;
        }
        local_20 = (void *)FUN_10007b70(local_18);
        local_1c = param_2 - *(int *)((int)this + 0xc) >> 2;
        local_24 = 0;
        local_8 = 0;
        FUN_10008350(this,(int)((int)local_20 + local_1c * 4),param_3,param_4);
        local_24 = local_24 + 1;
        do_is(this,*(undefined4 *)((int)this + 0xc),param_2,local_20);
        local_24 = local_24 + 1;
        do_is(this,param_2,*(undefined4 *)((int)this + 0x10),
              (void *)((int)local_20 + (local_1c + param_3) * 4));
        FUN_10008559();
        return;
      }
      if ((uint)(*(int *)((int)this + 0x10) - param_2 >> 2) < param_3) {
        uStack_28 = *param_4;
        do_is(this,param_2,*(undefined4 *)((int)this + 0x10),(void *)(param_2 + param_3 * 4));
        local_8 = 2;
        FUN_10008350(this,*(int *)((int)this + 0x10),
                     param_3 - (*(int *)((int)this + 0x10) - param_2 >> 2),&uStack_28);
        FUN_10008678();
        return;
      }
      uStack_30 = *param_4;
      iStack_2c = *(int *)((int)this + 0x10);
      uVar3 = do_is(this,iStack_2c + param_3 * -4,iStack_2c,*(void **)((int)this + 0x10));
      *(undefined4 *)((int)this + 0x10) = uVar3;
      iVar1 = iStack_2c + param_3 * -4;
      FUN_100088b0((uint3)iVar1,param_2,iVar1,iStack_2c);
      FUN_10008880(param_2,param_2 + param_3 * 4,&uStack_30);
    }
  }
  ExceptionList = local_10;
  return;
}

