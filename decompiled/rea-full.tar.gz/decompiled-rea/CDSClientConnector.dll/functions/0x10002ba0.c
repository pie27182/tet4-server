// rea decompile_all
// name: std::basic_string<char,std::char_traits<char>,std::_DebugHeapAllocator<char>_>::assign
// address: 0x10002ba0
// body: available
// range: 0x10002ba0-0x10002c55 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* Library Function - Single Match
    public: class std::basic_string<char,struct std::char_traits<char>,class
   std::_DebugHeapAllocator<char> > & __thiscall std::basic_string<char,struct
   std::char_traits<char>,class std::_DebugHeapAllocator<char> >::assign(class
   std::basic_string<char,struct std::char_traits<char>,class std::_DebugHeapAllocator<char> > const
   &,unsigned int,unsigned int)
   
   Library: Visual Studio 2005 Debug */

basic_string<char,struct_std::char_traits<char>,class_std::_DebugHeapAllocator<char>_> * __thiscall
std::basic_string<char,std::char_traits<char>,std::_DebugHeapAllocator<char>_>::assign
          (basic_string<char,std::char_traits<char>,std::_DebugHeapAllocator<char>_> *this,
          basic_string<char,struct_std::char_traits<char>,class_std::_DebugHeapAllocator<char>_>
          *param_1,uint param_2,uint param_3)

{
  bool bVar1;
  uint uVar2;
  int iVar3;
  char *pcVar4;
  char *pcVar5;
  uint uVar6;
  uint local_8;
  
  uVar2 = FUN_10001e90((int)param_1);
  if (uVar2 < param_2) {
    FUN_1000a896();
  }
  iVar3 = FUN_10001e90((int)param_1);
  local_8 = iVar3 - param_2;
  if (param_3 < local_8) {
    local_8 = param_3;
  }
  if (this == (basic_string<char,std::char_traits<char>,std::_DebugHeapAllocator<char>_> *)param_1)
  {
    basic_string<char,std::char_traits<char>,std::allocator<char>_>::erase
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)this,
               param_2 + local_8,0xffffffff);
    basic_string<char,std::char_traits<char>,std::allocator<char>_>::erase
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)this,0,param_2);
  }
  else {
    bVar1 = _Grow(this,local_8,false);
    if (bVar1) {
      uVar6 = local_8;
      pcVar4 = FID_conflict__Myptr(param_1);
      pcVar4 = pcVar4 + param_2;
      uVar2 = *(uint *)(this + 0x18);
      pcVar5 = FID_conflict__Myptr(this);
      _Traits_helper::copy_s<std::char_traits<char>_>(pcVar5,uVar2,pcVar4,uVar6);
      _Eos(this,local_8);
    }
  }
  return (basic_string<char,struct_std::char_traits<char>,class_std::_DebugHeapAllocator<char>_> *)
         this;
}

