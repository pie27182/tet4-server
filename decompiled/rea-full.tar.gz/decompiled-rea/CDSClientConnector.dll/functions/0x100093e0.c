// rea decompile_all
// name: _String_iterator<>
// address: 0x100093e0
// body: available
// range: 0x100093e0-0x100093ff inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* Library Function - Multiple Matches With Same Base Name
    public: __thiscall std::_String_iterator<char,struct std::char_traits<char>,class
   std::allocator<char> >::_String_iterator<char,struct std::char_traits<char>,class
   std::allocator<char> >(char *,struct std::_Container_base0 const *)
    public: __thiscall std::_String_iterator<class std::_String_val<struct std::_Simple_types<char>
   > >::_String_iterator<class std::_String_val<struct std::_Simple_types<char> > >(char *,struct
   std::_Container_base0 const *)
    public: __thiscall std::_String_iterator<class std::_String_val<struct std::_Simple_types<char>
   > >::_String_iterator<class std::_String_val<struct std::_Simple_types<char> > >(char *,struct
   std::_Container_base12 const *)
   
   Libraries: Visual Studio 2010 Release, Visual Studio 2012 Debug, Visual Studio 2012 Release */

void * __thiscall _String_iterator<>(void *this,char *param_1,void *param_2)

{
  FUN_10009b60(this,param_1,param_2);
  return this;
}

