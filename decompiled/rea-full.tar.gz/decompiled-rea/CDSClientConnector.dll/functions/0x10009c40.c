// rea decompile_all
// name: FUN_10009c40
// address: 0x10009c40
// body: available
// range: 0x10009c40-0x10009cee inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x10009ced to 0x10009d0d FUN_10009d0d (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


undefined4 * __thiscall FUN_10009c40(void *this,void *param_1)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined1 uVar4;
  void *pvVar5;
  int iVar6;
  undefined4 uStack_40;
  undefined1 local_28 [8];
  undefined1 local_20 [8];
  undefined1 *local_18;
  undefined1 *local_14;
  void *local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_10016eb8;
  local_10 = ExceptionList;
  uStack_40 = DAT_1001d02c ^ (uint)(local_20 + 0x1c);
  local_14 = (undefined1 *)&uStack_40;
  ExceptionList = &local_10;
  local_18 = local_28 + -0x1c;
  pvVar5 = this;
  std::allocator<char>::allocator<char>
            ((allocator<char> *)(local_28 + -0x1c),(allocator<char> *)((int)param_1 + 8));
  FUN_10007940(this,SUB41(pvVar5,0));
  local_8 = 0;
  uVar1 = FUN_10002e10((int)param_1);
  uVar1 = FUN_10002ed0(this,uVar1);
  if ((uVar1 & 0xff) == 0) {
    ExceptionList = local_10;
    return this;
  }
  local_8 = CONCAT31(local_8._1_3_,1);
  iVar6 = *(int *)((int)this + 0xc);
  puVar2 = FUN_100080e0(param_1,local_20);
  uVar3 = puVar2[1];
  uVar4 = (undefined1)*puVar2;
  puVar2 = FUN_10005dd0(param_1,local_28);
  uVar3 = FUN_1000a0e0(this,(char)*puVar2,puVar2[1],uVar4,uVar3,iVar6);
  *(undefined4 *)((int)this + 0x10) = uVar3;
  puVar2 = (undefined4 *)FUN_10009d0d();
  return puVar2;
}

