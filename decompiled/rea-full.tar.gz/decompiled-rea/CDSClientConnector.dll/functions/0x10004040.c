// rea decompile_all
// name: FUN_10004040
// address: 0x10004040
// body: available
// range: 0x10004040-0x1000410d inclusive
// range: 0x10004113-0x10004177 inclusive
// range: 0x1000417a-0x100041e1 inclusive
// range: 0x100041e4-0x10004200 inclusive
// non_contiguous: true
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Removing unreachable block (ram,0x100040dc) */
/* WARNING: Variable defined which should be unmapped: param_2 */

void * __thiscall FUN_10004040(undefined4 *param_1,void *param_2,undefined4 *param_3)

{
  bool bVar1;
  int *piVar2;
  char *pcVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined1 *puVar7;
  int local_50;
  undefined1 local_45;
  undefined1 local_44 [11];
  undefined1 local_39;
  undefined1 local_38 [11];
  undefined1 local_2d;
  undefined1 local_2c [20];
  int local_18 [2];
  int local_10;
  int local_c;
  char local_5;
  
  piVar2 = (int *)FUN_100039c0((int)param_1);
  local_10 = *piVar2;
  local_c = param_1[6];
  local_5 = '\x01';
  while (pcVar3 = (char *)FUN_10003050(local_10), *pcVar3 == '\0') {
    local_c = local_10;
    piVar2 = (int *)FUN_10003060(local_10);
    piVar4 = (int *)FUN_10003080(param_3);
    local_5 = FUN_10003be0(piVar4,piVar2);
    if ((bool)local_5) {
      piVar2 = (int *)FUN_10003080(local_10);
      local_50 = *piVar2;
    }
    else {
      piVar2 = (int *)FUN_100030a0(local_10);
      local_50 = *piVar2;
    }
    local_10 = local_50;
  }
  _Vector_iterator<>(local_18,local_c,param_1);
  if (local_5 != '\0') {
    piVar2 = FUN_10003ff0(param_1,local_2c);
    bVar1 = FUN_10003c40(local_18,piVar2);
    if (bVar1) {
      local_2d = 1;
      puVar7 = &local_2d;
      puVar6 = FUN_10004330(param_1,local_38,'\x01',local_c,param_3);
      FUN_10005230(param_2,puVar6,puVar7);
      return param_2;
    }
    FUN_10005040(local_18);
  }
  piVar2 = (int *)FUN_10003080(param_3);
  iVar5 = FUN_10003c90((int)local_18);
  piVar4 = (int *)FUN_10003060(iVar5);
  bVar1 = FUN_10003be0(piVar4,piVar2);
  if (bVar1) {
    local_39 = 1;
    puVar7 = &local_39;
    puVar6 = FUN_10004330(param_1,local_44,local_5,local_c,param_3);
    FUN_10005230(param_2,puVar6,puVar7);
  }
  else {
    local_45 = 0;
    FUN_10005230(param_2,local_18,&local_45);
  }
  return param_2;
}

