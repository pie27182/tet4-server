// rea decompile_all
// name: FUN_10003180
// address: 0x10003180
// body: available
// range: 0x10003180-0x100031bd inclusive
// range: 0x100031c3-0x10003377 inclusive
// range: 0x1000337a-0x1000339c inclusive
// range: 0x100033a2-0x1000347c inclusive
// range: 0x1000347f-0x10003653 inclusive
// range: 0x10003656-0x10003678 inclusive
// range: 0x1000367e-0x10003755 inclusive
// range: 0x10003758-0x1000379d inclusive
// non_contiguous: true
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Removing unreachable block (ram,0x100031cb) */
/* WARNING: Removing unreachable block (ram,0x10003240) */
/* WARNING: Removing unreachable block (ram,0x100032b9) */
/* WARNING: Removing unreachable block (ram,0x100032ee) */
/* WARNING: Removing unreachable block (ram,0x10003332) */
/* WARNING: Removing unreachable block (ram,0x1000337a) */
/* WARNING: Removing unreachable block (ram,0x10003355) */
/* WARNING: Removing unreachable block (ram,0x100033a2) */
/* WARNING: Removing unreachable block (ram,0x100033d7) */
/* WARNING: Removing unreachable block (ram,0x10003406) */
/* WARNING: Removing unreachable block (ram,0x10003437) */
/* WARNING: Removing unreachable block (ram,0x1000347f) */
/* WARNING: Removing unreachable block (ram,0x1000345a) */
/* WARNING: Removing unreachable block (ram,0x1000325c) */
/* WARNING: Removing unreachable block (ram,0x1000328f) */
/* WARNING: Removing unreachable block (ram,0x100032b4) */
/* WARNING: Removing unreachable block (ram,0x100031e7) */
/* WARNING: Removing unreachable block (ram,0x10003218) */
/* WARNING: Removing unreachable block (ram,0x1000323b) */
/* WARNING: Removing unreachable block (ram,0x100034a2) */
/* WARNING: Variable defined which should be unmapped: param_2 */

undefined4 * __thiscall
FUN_10003180(undefined4 *param_1,undefined4 *param_2,int param_3,undefined4 param_4,
            undefined4 *param_5)

{
  undefined4 uVar1;
  bool bVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  char *pcVar6;
  undefined4 *extraout_EAX;
  undefined4 *puVar7;
  undefined1 local_48 [12];
  undefined1 local_3c [8];
  undefined1 local_34 [8];
  undefined1 local_2c [32];
  int local_c;
  undefined4 local_8;
  
  _String_const_iterator<>(&local_c);
  iVar3 = FUN_10004020((int)param_1);
  if (iVar3 == 0) {
    FUN_10004330(param_1,param_2,'\x01',param_1[6],param_5);
    return param_2;
  }
  piVar4 = FUN_10003ff0(param_1,local_2c);
  bVar2 = FUN_10003c40(&param_3,piVar4);
  if (bVar2) {
    iVar3 = FUN_10003c90((int)&param_3);
    piVar4 = (int *)FUN_10003060(iVar3);
    piVar5 = (int *)FUN_10003080(param_5);
    bVar2 = FUN_10003be0(piVar5,piVar4);
    if (bVar2) {
      puVar7 = param_5;
      iVar3 = FUN_10003c90((int)&param_3);
      FUN_10004330(param_1,param_2,'\x01',iVar3,puVar7);
      return param_2;
    }
  }
  else {
    piVar4 = FUN_10003120(param_1,local_34);
    bVar2 = FUN_10003c40(&param_3,piVar4);
    if (bVar2) {
      piVar4 = (int *)FUN_10003080(param_5);
      piVar5 = (int *)FUN_100039a0((int)param_1);
      piVar5 = (int *)FUN_10003060(*piVar5);
      bVar2 = FUN_10003be0(piVar5,piVar4);
      if (bVar2) {
        puVar7 = param_5;
        piVar4 = (int *)FUN_100039a0((int)param_1);
        FUN_10004330(param_1,param_2,'\0',*piVar4,puVar7);
        return param_2;
      }
    }
    else {
      iVar3 = FUN_10003c90((int)&param_3);
      piVar4 = (int *)FUN_10003060(iVar3);
      piVar5 = (int *)FUN_10003080(param_5);
      bVar2 = FUN_10003be0(piVar5,piVar4);
      if (bVar2) {
        local_c = param_3;
        local_8 = param_4;
        piVar4 = (int *)FUN_10003080(param_5);
        piVar5 = FUN_10004930(&local_c);
        iVar3 = FUN_10003c90((int)piVar5);
        piVar5 = (int *)FUN_10003060(iVar3);
        bVar2 = FUN_10003be0(piVar5,piVar4);
        if (bVar2) {
          iVar3 = FUN_10003c90((int)&local_c);
          piVar4 = (int *)FUN_100030a0(iVar3);
          pcVar6 = (char *)FUN_10003050(*piVar4);
          if (*pcVar6 == '\0') {
            puVar7 = param_5;
            iVar3 = FUN_10003c90((int)&param_3);
            FUN_10004330(param_1,param_2,'\x01',iVar3,puVar7);
            return param_2;
          }
          puVar7 = param_5;
          iVar3 = FUN_10003c90((int)&local_c);
          FUN_10004330(param_1,param_2,'\0',iVar3,puVar7);
          return param_2;
        }
      }
      piVar4 = (int *)FUN_10003080(param_5);
      iVar3 = FUN_10003c90((int)&param_3);
      piVar5 = (int *)FUN_10003060(iVar3);
      bVar2 = FUN_10003be0(piVar5,piVar4);
      if (bVar2) {
        local_c = param_3;
        local_8 = param_4;
        piVar4 = FUN_10003120(param_1,local_3c);
        piVar5 = FUN_10003c20(&local_c);
        bVar2 = FUN_10003c40(piVar5,piVar4);
        if (!bVar2) {
          iVar3 = FUN_10003c90((int)&local_c);
          piVar4 = (int *)FUN_10003060(iVar3);
          piVar5 = (int *)FUN_10003080(param_5);
          bVar2 = FUN_10003be0(piVar5,piVar4);
          if (!bVar2) goto LAB_10003778;
        }
        iVar3 = FUN_10003c90((int)&param_3);
        piVar4 = (int *)FUN_100030a0(iVar3);
        pcVar6 = (char *)FUN_10003050(*piVar4);
        if (*pcVar6 == '\0') {
          puVar7 = param_5;
          iVar3 = FUN_10003c90((int)&local_c);
          FUN_10004330(param_1,param_2,'\x01',iVar3,puVar7);
          return param_2;
        }
        puVar7 = param_5;
        iVar3 = FUN_10003c90((int)&param_3);
        FUN_10004330(param_1,param_2,'\0',iVar3,puVar7);
        return param_2;
      }
    }
  }
LAB_10003778:
  FUN_10004040(param_1,local_48,param_5);
  uVar1 = extraout_EAX[1];
  *param_2 = *extraout_EAX;
  param_2[1] = uVar1;
  return param_2;
}

