// rea decompile_all
// name: xtoa_s
// address: 0x1000aae7
// body: available
// range: 0x1000aae7-0x1000abc3 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* Library Function - Single Match
    _xtoa_s@20
   
   Library: Visual Studio 2008 Release
   __stdcall xtoa_s,20 */

int xtoa_s(uint param_1,uint param_2,int param_3)

{
  char *pcVar1;
  uint in_EAX;
  int *piVar2;
  char *in_ECX;
  char *pcVar3;
  char cVar4;
  char *pcVar5;
  int iVar6;
  uint local_8;
  
  if (in_ECX == (char *)0x0) {
    piVar2 = __errno();
    *piVar2 = 0x16;
    __invalid_parameter((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
    return 0x16;
  }
  if (param_1 == 0) {
LAB_1000ab1b:
    piVar2 = __errno();
    iVar6 = 0x16;
  }
  else {
    *in_ECX = '\0';
    if ((param_3 != 0) + 1 < param_1) {
      if (0x22 < param_2 - 2) goto LAB_1000ab1b;
      pcVar5 = in_ECX;
      if (param_3 != 0) {
        *in_ECX = '-';
        pcVar5 = in_ECX + 1;
        in_EAX = -in_EAX;
      }
      local_8 = (uint)(param_3 != 0);
      pcVar1 = pcVar5;
      do {
        pcVar3 = pcVar1;
        cVar4 = (char)(in_EAX % param_2);
        if (in_EAX % param_2 < 10) {
          cVar4 = cVar4 + '0';
        }
        else {
          cVar4 = cVar4 + 'W';
        }
        *pcVar3 = cVar4;
        local_8 = local_8 + 1;
      } while ((in_EAX / param_2 != 0) &&
              (in_EAX = in_EAX / param_2, pcVar1 = pcVar3 + 1, local_8 < param_1));
      if (local_8 < param_1) {
        pcVar3[1] = '\0';
        do {
          cVar4 = *pcVar3;
          *pcVar3 = *pcVar5;
          pcVar3 = pcVar3 + -1;
          *pcVar5 = cVar4;
          pcVar5 = pcVar5 + 1;
        } while (pcVar5 < pcVar3);
        return 0;
      }
      *in_ECX = '\0';
    }
    piVar2 = __errno();
    iVar6 = 0x22;
  }
  *piVar2 = iVar6;
  __invalid_parameter((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
  return iVar6;
}

