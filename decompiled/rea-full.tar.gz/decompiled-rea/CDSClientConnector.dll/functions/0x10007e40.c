// rea decompile_all
// name: FUN_10007e40
// address: 0x10007e40
// body: available
// range: 0x10007e40-0x10007ed2 inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


uint __cdecl FUN_10007e40(_THandle *param_1,void *param_2)

{
  bool bVar1;
  uint3 extraout_var;
  int *piVar2;
  undefined3 extraout_var_00;
  undefined4 *puVar3;
  uint3 extraout_var_01;
  undefined1 local_18 [8];
  int local_10 [2];
  uint local_8;
  
  local_8 = FUN_10007800((int)param_2);
  if ((int)local_8 < 0x19001) {
    bVar1 = FUN_10005440(param_1,&local_8);
    if (bVar1) {
      FUN_10005dd0(param_2,local_10);
      while( true ) {
        piVar2 = FUN_100080e0(param_2,local_18);
        bVar1 = FUN_10003fb0(local_10,piVar2);
        if (!bVar1) break;
        puVar3 = (undefined4 *)FUN_10005ea0(local_10);
        bVar1 = FUN_10008210(param_1,puVar3);
        if (!bVar1) {
          return (uint)extraout_var_01 << 8;
        }
        FUN_10007bb0(local_10);
      }
      local_8 = CONCAT31(extraout_var_00,1);
    }
    else {
      local_8 = (uint)extraout_var << 8;
    }
  }
  else {
    local_8 = local_8 & 0xffffff00;
  }
  return local_8;
}

