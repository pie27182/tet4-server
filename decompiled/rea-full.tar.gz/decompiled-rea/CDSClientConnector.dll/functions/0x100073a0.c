// rea decompile_all
// name: FUN_100073a0
// address: 0x100073a0
// body: available
// range: 0x100073a0-0x1000744f inclusive
// non_contiguous: false
// provider: Ghidra 12.2 (ghidra)
// analysis_profile: af4d30c9d76866092ce084421f113cb34393a9703542b46a5c290a493c77a8c4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; Ghidra Program checkpoint mode is disabled: closing discards metadata edits; original executable bytes are unchanged. For stock ELF/PE/Mach-O on Linux/macOS, set REA_GHIDRA_CHECKPOINT_DIR to a private absolute directory before starting REA (restart MCP after changing its startup environment).; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; The Ghidra Program references PDB CDSClientConnector.pdb (GUID cb455e1e-912a-4528-9a10-19972293f08d, age (hex) 1, signature unknown, version RSDS); Ghidra reports load state unknown. Original names and types may be missing; an empty name search does not prove a procedure is absent. Use list_procedures and address-based analysis to inspect recovered functions. REA does not admit a caller-selected PDB companion.; This session uses Ghidra 12.2. The bridge is verified against 12.1.4; other 12.x (>=12.1) builds are accepted and the observed version is reported.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


uint __thiscall FUN_100073a0(void *this,_THandle *param_1)

{
  uint uVar1;
  uint3 uVar2;
  
  if ((*(char *)((int)this + 4) == '\0') &&
     (uVar1 = FUN_10005510(param_1,(undefined4 *)((int)this + 8)), (uVar1 & 0xff) == 0)) {
    return uVar1 & 0xffffff00;
  }
  uVar1 = FUN_10005510(param_1,(undefined4 *)((int)this + 0xc));
  if ((uVar1 & 0xff) == 0) {
    uVar1 = uVar1 & 0xffffff00;
  }
  else {
    uVar1 = FUN_10005510(param_1,(undefined4 *)((int)this + 0x10));
    if ((uVar1 & 0xff) == 0) {
      uVar1 = uVar1 & 0xffffff00;
    }
    else {
      uVar1 = FUN_10005530(param_1,(void *)((int)this + 0x14));
      if ((uVar1 & 0xff) == 0) {
        uVar1 = uVar1 & 0xffffff00;
      }
      else {
        uVar1 = FUN_10007d00(param_1,(void *)((int)this + 0x2c));
        uVar2 = (uint3)(uVar1 >> 8);
        if ((uVar1 & 0xff) == 0) {
          uVar1 = (uint)uVar2 << 8;
        }
        else {
          uVar1 = CONCAT31(uVar2,1);
        }
      }
    }
  }
  return uVar1;
}

